NUMBER MAGIC ANDROID — SOURCE PROJECT

App behavior:
- Volume Up: increases the hidden number from 1 to 9.
- Volume Down: reveals the selected number.
- The revealed number is drawn as a hand-drawn white stroke on a black screen.
- On-screen ↑ and ↓ buttons can also be used.
- × clears the screen. Double-tap the blank canvas to hide/show controls.
- Tap ? to set a number manually for testing.

IMPORTANT:
This ZIP contains Android source code, not a prebuilt APK.

BUILD APK WITH ANDROID STUDIO:
1. Open the NumberMagicAndroid folder in Android Studio.
2. Allow Gradle sync; use JDK 17 and Android SDK Platform 35.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.

BUILD APK FROM A PHONE USING GITHUB ACTIONS:
1. Create a GitHub repository and upload the CONTENTS of this folder to it (so build.gradle is at the repository root).
2. Open the repository's Actions tab and select “Build Number Magic APK”.
3. Tap “Run workflow” if it has not run automatically after upload.
4. When the workflow finishes successfully, open that run and download the “NumberMagic-debug-apk” artifact.
5. Extract the downloaded artifact ZIP to get app-debug.apk, then open it on your Android phone to install. Android may ask you to allow installs from that source.

The APK is a debug build for testing, not a Play Store release.
